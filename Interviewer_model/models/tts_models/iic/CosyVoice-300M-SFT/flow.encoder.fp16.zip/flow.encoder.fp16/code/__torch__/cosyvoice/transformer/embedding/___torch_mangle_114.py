class EspnetRelPositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  pe : Tensor
