class LinearNoSubsampling(Module):
  __parameters__ = []
  __buffers__ = []
  pos_enc : __torch__.cosyvoice.transformer.embedding.___torch_mangle_114.EspnetRelPositionalEncoding
